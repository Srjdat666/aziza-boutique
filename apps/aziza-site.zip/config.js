/* config.js — إعدادات الاتصال بـ Supabase
   المفتاح هنا هو Publishable key (آمن للنشر). لا تضعي secret / service_role أبداً. */
window.AZIZA_CONFIG = {
  url: 'https://uqzltkgtqwwjruzoflbb.supabase.co',   // تأكدي أنه نفس Project URL من زر Connect
  key: 'PASTE_YOUR_PUBLISHABLE_KEY_HERE'              // يبدأ بـ sb_publishable_
};
